#ifndef GNSS_PARSER_H
#define GNSS_PARSER_H

/**
 * @file gnss_parser.h
 * @brief GNSS NMEA & UBX Protocol Parser for u-blox modules
 *
 * Supports:
 *   NMEA 0183: GGA, RMC, GSA, GSV, VTG, GLL
 *   UBX Binary:  NAV-PVT, NAV-STATUS, ACK-ACK, ACK-NAK
 *
 * Designed for embedded targets (no heap allocation, no stdlib deps beyond stdint).
 */

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

/* ──────────────────────────────────────────────
   Constants
   ────────────────────────────────────────────── */

#define GNSS_MAX_SATELLITES     32
#define GNSS_NMEA_MAX_LEN      128
#define GNSS_UBX_MAX_PAYLOAD   512

#define NMEA_START_CHAR        '$'
#define UBX_SYNC1              0xB5
#define UBX_SYNC2              0x62

/* UBX Class IDs */
#define UBX_CLASS_NAV          0x01
#define UBX_CLASS_ACK          0x05
#define UBX_CLASS_CFG          0x06

/* UBX Message IDs */
#define UBX_ID_NAV_PVT         0x07
#define UBX_ID_NAV_STATUS      0x03
#define UBX_ID_ACK_ACK         0x01
#define UBX_ID_ACK_NAK         0x00

/* ──────────────────────────────────────────────
   Return Codes
   ────────────────────────────────────────────── */

typedef enum {
    GNSS_OK              =  0,
    GNSS_ERR_INVALID     = -1,   /* Null ptr or bad args         */
    GNSS_ERR_CHECKSUM    = -2,   /* Checksum mismatch            */
    GNSS_ERR_INCOMPLETE  = -3,   /* Not enough bytes yet         */
    GNSS_ERR_UNKNOWN_MSG = -4,   /* Unknown sentence/class/id    */
    GNSS_ERR_OVERFLOW    = -5,   /* Buffer too small             */
} gnss_err_t;

/* ──────────────────────────────────────────────
   NMEA Data Structures
   ────────────────────────────────────────────── */

typedef enum {
    GPS_FIX_NONE   = 0,
    GPS_FIX_GPS    = 1,
    GPS_FIX_DGPS   = 2,
    GPS_FIX_PPS    = 3,
    GPS_FIX_RTK    = 4,
    GPS_FIX_FRTK   = 5,
    GPS_FIX_EST    = 6,
} gps_fix_quality_t;

typedef struct {
    int32_t  degrees;           /* Integer degrees            */
    double   minutes;           /* Decimal minutes            */
    char     direction;         /* N/S or E/W                 */
    double   decimal;           /* Precomputed decimal degrees */
} nmea_coord_t;

/** $GPGGA – Fix Information */
typedef struct {
    uint8_t          hour;
    uint8_t          minute;
    uint8_t          second;
    uint16_t         millisecond;
    nmea_coord_t     latitude;
    nmea_coord_t     longitude;
    gps_fix_quality_t fix_quality;
    uint8_t          num_satellites;
    double           hdop;            /* Horizontal dilution of precision */
    double           altitude_m;      /* Above mean sea level             */
    double           geoid_sep_m;     /* Geoid separation                 */
    bool             valid;
} nmea_gga_t;

/** $GPRMC – Recommended Minimum Sentence */
typedef struct {
    uint8_t      hour;
    uint8_t      minute;
    uint8_t      second;
    char         status;          /* 'A' active, 'V' void     */
    nmea_coord_t latitude;
    nmea_coord_t longitude;
    double       speed_knots;
    double       course_deg;
    uint8_t      day;
    uint8_t      month;
    uint16_t     year;
    bool         valid;
} nmea_rmc_t;

/** Satellite info (from $GPGSV) */
typedef struct {
    uint8_t  prn;
    int8_t   elevation_deg;
    uint16_t azimuth_deg;
    uint8_t  snr_db;            /* 0 = no signal             */
} nmea_satellite_t;

/** $GPGSV – Satellites in View */
typedef struct {
    uint8_t          total_msgs;
    uint8_t          msg_num;
    uint8_t          total_sats;
    uint8_t          sat_count;
    nmea_satellite_t sats[GNSS_MAX_SATELLITES];
    bool             valid;
} nmea_gsv_t;

/** $GPGSA – Dilution of Precision & Active Satellites */
typedef struct {
    char    mode;           /* 'M' manual, 'A' auto          */
    uint8_t fix_type;       /* 1=none, 2=2D, 3=3D            */
    uint8_t prn_used[12];
    double  pdop;
    double  hdop;
    double  vdop;
    bool    valid;
} nmea_gsa_t;

/** $GPVTG – Course over Ground & Ground Speed */
typedef struct {
    double  course_true_deg;
    double  course_mag_deg;
    double  speed_knots;
    double  speed_kmh;
    bool    valid;
} nmea_vtg_t;

/** Aggregated NMEA snapshot */
typedef struct {
    nmea_gga_t gga;
    nmea_rmc_t rmc;
    nmea_gsv_t gsv;
    nmea_gsa_t gsa;
    nmea_vtg_t vtg;
} nmea_data_t;

/* ──────────────────────────────────────────────
   UBX Binary Structures
   ────────────────────────────────────────────── */

/** UBX frame header (little-endian on wire) */
typedef struct __attribute__((packed)) {
    uint8_t  sync1;        /* 0xB5                          */
    uint8_t  sync2;        /* 0x62                          */
    uint8_t  cls;
    uint8_t  id;
    uint16_t length;       /* Payload length (bytes)        */
} ubx_header_t;

/** UBX-NAV-PVT (0x01 0x07) – Position Velocity Time */
typedef struct __attribute__((packed)) {
    uint32_t iTOW;         /* GPS time of week [ms]         */
    uint16_t year;
    uint8_t  month;
    uint8_t  day;
    uint8_t  hour;
    uint8_t  min;
    uint8_t  sec;
    uint8_t  valid;        /* Validity flags                */
    uint32_t tAcc;         /* Time accuracy estimate [ns]   */
    int32_t  nano;         /* Fraction of second [ns]       */
    uint8_t  fixType;      /* 0=none 1=DR 2=2D 3=3D 4=GNSS+DR 5=time */
    uint8_t  flags;        /* Fix status flags              */
    uint8_t  flags2;
    uint8_t  numSV;        /* Satellites used               */
    int32_t  lon;          /* Longitude [1e-7 deg]          */
    int32_t  lat;          /* Latitude  [1e-7 deg]          */
    int32_t  height;       /* Height above ellipsoid [mm]   */
    int32_t  hMSL;         /* Height above mean sea level [mm] */
    uint32_t hAcc;         /* Horizontal accuracy [mm]      */
    uint32_t vAcc;         /* Vertical   accuracy [mm]      */
    int32_t  velN;         /* NED north velocity [mm/s]     */
    int32_t  velE;         /* NED east  velocity [mm/s]     */
    int32_t  velD;         /* NED down  velocity [mm/s]     */
    int32_t  gSpeed;       /* Ground speed [mm/s]           */
    int32_t  headMot;      /* Heading of motion [1e-5 deg]  */
    uint32_t sAcc;         /* Speed accuracy [mm/s]         */
    uint32_t headAcc;      /* Heading accuracy [1e-5 deg]   */
    uint16_t pDOP;         /* Position DOP [0.01]           */
    uint8_t  reserved1[6];
    int32_t  headVeh;      /* Heading of vehicle [1e-5 deg] */
    int16_t  magDec;       /* Magnetic declination [1e-2 deg] */
    uint16_t magAcc;       /* Magnetic decl. accuracy       */
} ubx_nav_pvt_t;

/** UBX-NAV-STATUS (0x01 0x03) */
typedef struct __attribute__((packed)) {
    uint32_t iTOW;
    uint8_t  gpsFix;
    uint8_t  flags;
    uint8_t  fixStat;
    uint8_t  flags2;
    uint32_t ttff;         /* Time to first fix [ms]        */
    uint32_t msss;         /* Milliseconds since startup    */
} ubx_nav_status_t;

/** UBX-ACK (0x05 0x01 / 0x05 0x00) */
typedef struct __attribute__((packed)) {
    uint8_t clsID;
    uint8_t msgID;
} ubx_ack_t;

/** Parsed UBX result union */
typedef enum {
    UBX_MSG_UNKNOWN,
    UBX_MSG_NAV_PVT,
    UBX_MSG_NAV_STATUS,
    UBX_MSG_ACK_ACK,
    UBX_MSG_ACK_NAK,
} ubx_msg_type_t;

typedef struct {
    ubx_msg_type_t type;
    union {
        ubx_nav_pvt_t    nav_pvt;
        ubx_nav_status_t nav_status;
        ubx_ack_t        ack;
    } payload;
} ubx_message_t;

/* ──────────────────────────────────────────────
   Parser State Machine (streaming byte feed)
   ────────────────────────────────────────────── */

typedef enum {
    PARSE_STATE_IDLE,
    PARSE_STATE_NMEA,           /* Accumulating NMEA sentence     */
    PARSE_STATE_UBX_SYNC2,      /* Got 0xB5, waiting for 0x62     */
    PARSE_STATE_UBX_HEADER,     /* Reading 4-byte class/id/len    */
    PARSE_STATE_UBX_PAYLOAD,    /* Reading payload                */
    PARSE_STATE_UBX_CK,         /* Reading 2 checksum bytes       */
} parse_state_t;

typedef void (*nmea_sentence_cb)(const char *sentence, void *ctx);
typedef void (*ubx_message_cb)(const ubx_message_t *msg, void *ctx);

typedef struct {
    parse_state_t state;

    /* NMEA accumulation */
    char     nmea_buf[GNSS_NMEA_MAX_LEN];
    uint16_t nmea_len;

    /* UBX accumulation */
    uint8_t  ubx_buf[GNSS_UBX_MAX_PAYLOAD + sizeof(ubx_header_t) + 2];
    uint16_t ubx_len;
    uint16_t ubx_expected;
    uint8_t  ubx_ck_a;
    uint8_t  ubx_ck_b;

    /* Callbacks */
    nmea_sentence_cb on_nmea;
    ubx_message_cb   on_ubx;
    void            *cb_ctx;
} gnss_parser_ctx_t;

/* ──────────────────────────────────────────────
   Public API
   ────────────────────────────────────────────── */

/** Initialise parser context. Must be called once before use. */
gnss_err_t gnss_parser_init(gnss_parser_ctx_t *ctx,
                             nmea_sentence_cb on_nmea,
                             ubx_message_cb   on_ubx,
                             void            *cb_ctx);

/**
 * Feed raw bytes from UART into the parser.
 * Call this inside your UART ISR or DMA complete callback.
 */
gnss_err_t gnss_parser_feed(gnss_parser_ctx_t *ctx,
                              const uint8_t *buf,
                              size_t len);

/* ──────────────────────── NMEA sentence parsers ──────────────────── */
gnss_err_t nmea_parse_gga(const char *sentence, nmea_gga_t *out);
gnss_err_t nmea_parse_rmc(const char *sentence, nmea_rmc_t *out);
gnss_err_t nmea_parse_gsv(const char *sentence, nmea_gsv_t *out);
gnss_err_t nmea_parse_gsa(const char *sentence, nmea_gsa_t *out);
gnss_err_t nmea_parse_vtg(const char *sentence, nmea_vtg_t *out);
uint8_t    nmea_checksum(const char *sentence);   /* XOR checksum     */

/* ──────────────────────── UBX parsers ────────────────────────────── */
gnss_err_t ubx_parse_message(const uint8_t *buf, size_t len,
                              ubx_message_t *out);
void       ubx_compute_checksum(const uint8_t *buf, size_t payload_len,
                                 uint8_t *ck_a, uint8_t *ck_b);
bool       ubx_verify_checksum(const uint8_t *frame, size_t total_len);

/* ──────────────────────── Utility helpers ─────────────────────────── */
double     nmea_coord_to_decimal(const nmea_coord_t *c);
double     gnss_haversine_m(double lat1, double lon1,
                             double lat2, double lon2);
const char *gnss_fix_type_str(uint8_t fix_type);

#endif /* GNSS_PARSER_H */
